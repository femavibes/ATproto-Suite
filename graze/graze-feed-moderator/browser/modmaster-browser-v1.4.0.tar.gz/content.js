// Content script for Bluesky Feed Moderator
class BlueskyModerator {
  constructor() {
    this.apiKey = null;
    this.apiUrl = null;
    this.userInfo = null;
    this.init();
  }

  async init() {
    console.log('Feed Moderator: Initializing...');
    
    // Get settings from storage
    const result = await chrome.storage.sync.get(['apiKey', 'apiUrl', 'dryRunMode']);
    this.apiKey = result.apiKey;
    this.apiUrl = result.apiUrl || 'https://modmaster.fema.monster';
    this.dryRunMode = result.dryRunMode || false;
    
    console.log('Feed Moderator: API Key present:', !!this.apiKey);
    console.log('Feed Moderator: API URL:', this.apiUrl);
    console.log('Feed Moderator: Dry Run Mode:', this.dryRunMode);
    
    if (!this.apiKey) {
      console.log('Feed Moderator: No API key configured');
      return;
    }

    // Get user info
    await this.loadUserInfo();
    
    // Start observing for new content
    this.observeContent();
    
    // Process existing content
    this.processExistingContent();
    
    console.log('Feed Moderator: Initialization complete');
  }

  async loadUserInfo() {
    try {
      const response = await fetch(`${this.apiUrl}/api/extension/user/profile`, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`
        }
      });
      
      if (response.ok) {
        this.userInfo = await response.json();
        console.log('Feed Moderator: Loaded user info', this.userInfo.user.handle);
      }
    } catch (error) {
      console.error('Feed Moderator: Failed to load user info', error);
    }
  }

  observeContent() {
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            this.processElement(node);
          }
        });
      });
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  processExistingContent() {
    console.log('Feed Moderator: Processing existing content...');
    
    // Wait a bit for page to load
    setTimeout(() => {
      this.findAndProcessPosts();
    }, 2000);
    
    // Also try immediately
    this.findAndProcessPosts();
    
    // Set up URL change detection for SPA navigation
    let lastUrl = window.location.href;
    const checkUrlChange = () => {
      if (window.location.href !== lastUrl) {
        lastUrl = window.location.href;
        console.log('ModMaster: URL changed, reprocessing posts');
        setTimeout(() => {
          this.findAndProcessPosts();
        }, 1000);
      }
    };
    
    // Check for URL changes every 500ms
    setInterval(checkUrlChange, 500);
  }
  
  findAndProcessPosts() {
    // Remove existing moderation UI first to avoid duplicates
    document.querySelectorAll('.fm-post-actions').forEach(el => el.remove());
    
    // Use the correct Bluesky selectors based on page analysis
    const selectors = [
      // Current Bluesky post selectors (found in analysis)
      '[data-testid^="feedItem-by-"]',
      // Fallback selectors
      '[data-testid="feedItem"]',
      '[data-testid="postThreadItem"]'
    ];
    
    let posts = [];
    for (const selector of selectors) {
      try {
        posts = document.querySelectorAll(selector);
        console.log(`Feed Moderator: Selector "${selector}" found`, posts.length, 'elements');
        if (posts.length > 0) {
          console.log('Feed Moderator: Sample element:', posts[0]);
          break;
        }
      } catch (e) {
        console.log(`Feed Moderator: Selector "${selector}" failed:`, e.message);
      }
    }
    
    posts.forEach(post => {
      this.addPostModerationUI(post);
    });

    // Process profiles
    if (window.location.pathname.startsWith('/profile/')) {
      console.log('Feed Moderator: On profile page, adding profile UI');
      this.addProfileModerationUI();
    }
    
    console.log(`Feed Moderator: Processed ${posts.length} posts`);
  }

  processElement(element) {
    // Check for new posts using correct selectors
    if (element.matches && element.matches('[data-testid^="feedItem-by-"]')) {
      this.addPostModerationUI(element);
      return;
    }
    
    // Check for posts within the element
    if (element.querySelectorAll) {
      element.querySelectorAll('[data-testid^="feedItem-by-"]').forEach(post => {
        this.addPostModerationUI(post);
      });
    }

    // Check if we're on a profile page
    if (window.location.pathname.startsWith('/profile/')) {
      this.addProfileModerationUI();
    }
  }

  addPostModerationUI(postElement) {
    // Skip if already processed
    if (postElement.querySelector('.fm-post-actions')) return;

    console.log('Feed Moderator: Processing post element:', postElement);

    // Find the bottom of the post to add our buttons
    let insertLocation = postElement;
    
    // Try to find a better insertion point (after post content, before engagement buttons)
    const postText = postElement.querySelector('[data-testid="postText"]');
    if (postText) {
      insertLocation = postText.parentElement;
    }

    // Extract post info from the data-testid
    const testId = postElement.getAttribute('data-testid');
    if (!testId || !testId.startsWith('feedItem-by-')) {
      console.log('Feed Moderator: Invalid post testId:', testId);
      return;
    }
    
    const authorHandle = testId.replace('feedItem-by-', '');
    
    // Try to find post URI from links
    const postLink = postElement.querySelector('a[href*="/post/"]');
    let postUri = null;
    
    if (postLink) {
      const href = postLink.getAttribute('href');
      const match = href.match(/\/profile\/([^\/]+)\/post\/([^\/\?]+)/);
      if (match) {
        const [, handle, postId] = match;
        postUri = `at://${handle.replace('@', '')}/app.bsky.feed.post/${postId}`;
      }
    }

    const postInfo = {
      uri: postUri,
      authorHandle: authorHandle,
      element: postElement
    };

    console.log('Feed Moderator: Adding moderation UI for post:', postInfo);

    // Create moderation buttons - get fresh feed info each time
    const buttonsContainer = this.createPostDropdown(postInfo);
    insertLocation.appendChild(buttonsContainer);
  }

  extractPostInfo(postElement) {
    try {
      // Try to find the post URI from various possible locations
      const linkElement = postElement.querySelector('a[href*="/post/"]');
      if (!linkElement) return null;

      const href = linkElement.getAttribute('href');
      const match = href.match(/\/profile\/([^\/]+)\/post\/([^\/\?]+)/);
      if (!match) return null;

      const [, handle, postId] = match;
      const postUri = `at://${handle.replace('@', '')}/app.bsky.feed.post/${postId}`;

      // Extract author handle
      const authorElement = postElement.querySelector('[data-testid="authorHandle"]');
      const authorHandle = authorElement ? authorElement.textContent.replace('@', '') : handle.replace('@', '');

      return {
        uri: postUri,
        authorHandle: authorHandle,
        element: postElement
      };
    } catch (error) {
      console.error('Failed to extract post info:', error);
      return null;
    }
  }

  createPostDropdown(postInfo) {
    const container = document.createElement('div');
    container.className = 'fm-post-actions';
    container.style.cssText = `
      display: flex;
      gap: 8px;
      padding: 8px 0;
      border-top: 1px solid #e1e8ed;
      margin-top: 8px;
    `;

    const currentFeed = this.getCurrentFeed();
    console.log('ModMaster: Current feed:', currentFeed);

    // Ban User button (always available)
    const banBtn = document.createElement('button');
    banBtn.textContent = '🚫 Ban User';
    banBtn.style.cssText = `
      background: #dc3545;
      color: white;
      border: none;
      padding: 6px 12px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 12px;
      font-weight: 500;
    `;
    banBtn.onclick = (e) => {
      e.stopPropagation();
      
      // Check for dry run mode
      if (this.dryRunMode) {
        this.dryRunAction('banUser', {
          handle: postInfo.authorHandle,
          targets: ['global'],
          description: `Ban ${postInfo.authorHandle} from global list`
        });
        return;
      }
      
      if (confirm(`Ban ${postInfo.authorHandle} from global list?`)) {
        this.banUser(postInfo.authorHandle, ['global']);
      }
    };

    // Remove from Current Feed button (disable for built-in feeds)
    const removeCurrentBtn = document.createElement('button');
    const isBuiltInFeed = ['Following', 'Discover', 'Popular', 'Profile'].includes(currentFeed);
    removeCurrentBtn.textContent = `🗑️ Remove from ${currentFeed}`;
    removeCurrentBtn.style.cssText = `
      background: ${isBuiltInFeed ? '#6c757d' : '#ffc107'};
      color: ${isBuiltInFeed ? '#fff' : '#000'};
      border: none;
      padding: 6px 12px;
      border-radius: 4px;
      cursor: ${isBuiltInFeed ? 'not-allowed' : 'pointer'};
      font-size: 12px;
      font-weight: 500;
      opacity: ${isBuiltInFeed ? '0.6' : '1'};
    `;
    
    if (isBuiltInFeed) {
      removeCurrentBtn.title = 'Cannot moderate built-in Bluesky feeds';
      removeCurrentBtn.onclick = (e) => {
        e.stopPropagation();
        this.showNotification('Cannot moderate built-in Bluesky feeds', 'error');
      };
    } else {
      removeCurrentBtn.onclick = (e) => {
        e.stopPropagation();
        
        // Check for dry run mode
        if (this.dryRunMode) {
          this.dryRunAction('removePost', {
            postUri: postInfo.uri,
            targets: [currentFeed],
            description: `Remove post from ${currentFeed}`
          });
          return;
        }
        
        if (confirm(`Remove this post from ${currentFeed}?`)) {
          this.removePost(postInfo.uri, [currentFeed]);
        }
      };
    }

    // Remove from My Feeds button (removes from all user's feeds)
    const removeMyFeedsBtn = document.createElement('button');
    removeMyFeedsBtn.textContent = '🗑️ Remove from My Feeds';
    removeMyFeedsBtn.style.cssText = `
      background: #6c757d;
      color: white;
      border: none;
      padding: 6px 12px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 12px;
      font-weight: 500;
    `;
    removeMyFeedsBtn.onclick = (e) => {
      e.stopPropagation();
      
      // Check for dry run mode
      if (this.dryRunMode) {
        this.dryRunAction('removePost', {
          postUri: postInfo.uri,
          targets: [],
          description: 'Remove post from all your feeds'
        });
        return;
      }
      
      if (confirm('Remove this post from all your feeds?')) {
        this.removePost(postInfo.uri, []);
      }
    };

    container.appendChild(banBtn);
    container.appendChild(removeCurrentBtn);
    container.appendChild(removeMyFeedsBtn);
    return container;
  }

  addProfileModerationUI() {
    // Skip if already processed
    if (document.querySelector('.fm-profile-actions')) return;

    // Find profile header
    const profileHeader = document.querySelector('[data-testid="profileHeaderDisplayName"]')?.parentElement?.parentElement;
    if (!profileHeader) return;

    // Extract profile handle
    const handleElement = document.querySelector('[data-testid="profileHeaderHandle"]');
    if (!handleElement) return;

    const handle = handleElement.textContent.replace('@', '');

    // Create moderation panel
    const panel = this.createProfilePanel(handle);
    profileHeader.appendChild(panel);
  }

  createProfilePanel(handle) {
    const panel = document.createElement('div');
    panel.className = 'fm-profile-actions';
    panel.style.cssText = `
      margin-top: 12px;
      padding: 12px;
      background: #f8f9fa;
      border-radius: 8px;
      border: 1px solid #e1e8ed;
    `;

    const title = document.createElement('div');
    title.textContent = '🛡️ Feed Moderator';
    title.style.cssText = 'font-weight: bold; margin-bottom: 8px; font-size: 14px;';

    const buttonContainer = document.createElement('div');
    buttonContainer.style.cssText = 'display: flex; gap: 8px; flex-wrap: wrap;';

    const buttons = [
      { text: 'Ban from Global', action: () => this.banUser(handle, ['global']) },
      { text: 'Ban from All Feeds', action: () => this.banUser(handle, []) },
      { text: 'Unban from Global', action: () => this.unbanUser(handle, ['global']) },
      { text: 'Unban from All', action: () => this.unbanUser(handle, []) }
    ];

    buttons.forEach(btn => {
      const button = document.createElement('button');
      button.textContent = btn.text;
      button.style.cssText = `
        padding: 6px 12px;
        background: #1d9bf0;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
      `;
      button.onmouseover = () => button.style.backgroundColor = '#1a8cd8';
      button.onmouseout = () => button.style.backgroundColor = '#1d9bf0';
      button.onclick = btn.action;
      buttonContainer.appendChild(button);
    });

    panel.appendChild(title);
    panel.appendChild(buttonContainer);
    return panel;
  }

  async banUser(handle, targets = ['global']) {
    if (!this.apiKey) {
      this.showNotification('No API key configured', 'error');
      return;
    }

    try {
      const response = await fetch(`${this.apiUrl}/api/extension/moderation/ban`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ handle, targets })
      });

      const result = await response.json();
      if (response.ok) {
        this.showNotification(`Banned ${handle} successfully`, 'success');
      } else {
        this.showNotification(result.error || 'Ban failed', 'error');
      }
    } catch (error) {
      this.showNotification('Network error', 'error');
      console.error('Ban error:', error);
    }
  }

  async unbanUser(handle, targets = ['global']) {
    if (!this.apiKey) {
      this.showNotification('No API key configured', 'error');
      return;
    }

    try {
      const response = await fetch(`${this.apiUrl}/api/extension/moderation/unban`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ handle, targets })
      });

      const result = await response.json();
      if (response.ok) {
        this.showNotification(`Unbanned ${handle} successfully`, 'success');
      } else {
        this.showNotification(result.error || 'Unban failed', 'error');
      }
    } catch (error) {
      this.showNotification('Network error', 'error');
      console.error('Unban error:', error);
    }
  }

  async removePost(postUri, targets = []) {
    if (!this.apiKey) {
      this.showNotification('No API key configured', 'error');
      return;
    }

    try {
      const response = await fetch(`${this.apiUrl}/api/extension/moderation/remove`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ postUri, targets })
      });

      const result = await response.json();
      if (response.ok) {
        this.showNotification('Post removed successfully', 'success');
      } else {
        this.showNotification(result.error || 'Remove failed', 'error');
      }
    } catch (error) {
      this.showNotification('Network error', 'error');
      console.error('Remove error:', error);
    }
  }

  dryRunAction(actionType, params) {
    const apiCall = {
      url: `${this.apiUrl}/api/extension/moderation/${actionType === 'banUser' ? 'ban' : 'remove'}`,
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(params)
    };
    
    const dryRunInfo = `🧪 DRY RUN MODE\n\nAction: ${params.description}\nCurrent Feed: ${this.getCurrentFeed()}\n\nAPI Call that would be made:\n${JSON.stringify(apiCall, null, 2)}`;
    
    console.log('ModMaster Dry Run:', apiCall);
    
    // Copy to clipboard
    navigator.clipboard.writeText(dryRunInfo).then(() => {
      alert(dryRunInfo + '\n\n✅ Copied to clipboard!');
    }).catch(() => {
      alert(dryRunInfo);
    });
  }

  canModerateCurrentFeed(feedName) {
    // Can't moderate Bluesky's built-in feeds
    const builtInFeeds = ['Following', 'Discover', 'What\'s Hot Classic'];
    if (builtInFeeds.includes(feedName)) {
      return false;
    }
    
    // For now, assume user can moderate custom feeds they're viewing
    // TODO: Check against user's actual feed list from userInfo
    if (this.userInfo && this.userInfo.feeds) {
      return this.userInfo.feeds.some(feed => 
        feed.displayName === feedName || feed.uri.includes(feedName)
      );
    }
    
    // Conservative fallback - only show for feeds that look like user feeds
    return feedName !== 'Following' && feedName !== 'Discover' && !feedName.includes('Trending');
  }

  getCurrentFeed() {
    // Detect current feed from DOM elements since bsky.app doesn't always show feed in URL
    console.log('ModMaster: Detecting current feed from DOM');
    
    // Method 1: Check page title (most reliable)
    const title = document.title.replace(' — Bluesky', '').replace(' / Bluesky', '').trim();
    if (title && title !== 'Bluesky' && title !== 'Home') {
      console.log('ModMaster: Found feed name in title:', title);
      return title;
    }
    
    // Method 2: Look for feed header/name in the page
    const feedSelectors = [
      'h1',
      '[role="heading"]',
      '[data-testid*="feedHeader"]',
      '[data-testid*="feed-name"]',
      '.feed-header',
      '.feed-title'
    ];
    
    for (const selector of feedSelectors) {
      const elements = document.querySelectorAll(selector);
      for (const element of elements) {
        const text = element.textContent?.trim();
        if (text && text.length > 0 && text !== 'Home' && text !== 'Bluesky' && !text.includes('Back')) {
          console.log(`ModMaster: Found feed name "${text}" from ${selector}`);
          return text;
        }
      }
    }
    
    // Method 3: Check for active tab or navigation element
    const navSelectors = [
      '[aria-selected="true"]',
      '.active',
      '[data-testid*="tab"][aria-selected="true"]'
    ];
    
    for (const selector of navSelectors) {
      const elements = document.querySelectorAll(selector);
      for (const element of elements) {
        const text = element.textContent?.trim();
        if (text && text.length > 0 && text !== 'Home' && !text.includes('Following')) {
          console.log(`ModMaster: Found feed name "${text}" from active nav ${selector}`);
          return text;
        }
      }
    }
    
    // Method 4: Check URL as last resort
    const url = window.location.href;
    const feedMatch = url.match(/\/profile\/[^\/]+\/feed\/([^\/\?]+)/);
    if (feedMatch) {
      console.log('ModMaster: Found feed ID in URL:', feedMatch[1]);
      return feedMatch[1];
    }
    
    // Default to following for home timeline
    console.log('ModMaster: Defaulting to following');
    return 'following';
  }

  addTestButton() {
    testButton.innerHTML = '🛡️ ModMaster Active - Click to inspect page<br><small>Toggle dry run in popup settings</small>';
    testButton.style.cssText = `
      position: fixed;
      top: 10px;
      left: 10px;
      background: #1d9bf0;
      color: white;
      padding: 8px 12px;
      border-radius: 4px;
      font-size: 12px;
      z-index: 10000;
      cursor: pointer;
      line-height: 1.3;
    `;
    testButton.onclick = () => {
      // Show page structure info
      const allDivs = document.querySelectorAll('div').length;
      const allButtons = document.querySelectorAll('button').length;
      const testIds = Array.from(document.querySelectorAll('[data-testid]')).map(el => el.getAttribute('data-testid')).slice(0, 20);
      const allTestIds = Array.from(document.querySelectorAll('[data-testid]')).map(el => el.getAttribute('data-testid')).filter((v,i,a) => a.indexOf(v) === i).sort();
      
      const info = `ModMaster Page Analysis:

Total divs: ${allDivs}
Total buttons: ${allButtons}
URL: ${window.location.href}

First 20 data-testid values:
${testIds.join('\n')}

All unique data-testid values (${allTestIds.length} total):
${allTestIds.join('\n')}`;
      
      console.log('ModMaster Page Analysis:', {
        totalDivs: allDivs,
        totalButtons: allButtons,
        firstTestIds: testIds,
        allTestIds: allTestIds,
        url: window.location.href
      });
      
      // Copy to clipboard
      navigator.clipboard.writeText(info).then(() => {
        this.showNotification('Page analysis copied to clipboard!', 'success');
      }).catch(() => {
        // Fallback: show in alert if clipboard fails
        alert(info);
      });
    };
    document.body.appendChild(testButton);
    console.log('Feed Moderator: Added test button with page analysis');
  }

  showNotification(message, type = 'info') {
    // Remove existing notification
    const existing = document.querySelector('.fm-notification');
    if (existing) existing.remove();

    const notification = document.createElement('div');
    notification.className = 'fm-notification';
    notification.textContent = message;
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 12px 16px;
      border-radius: 8px;
      color: white;
      font-weight: 500;
      z-index: 10000;
      max-width: 300px;
      background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
    `;

    document.body.appendChild(notification);

    setTimeout(() => {
      notification.remove();
    }, 3000);
  }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => new BlueskyModerator());
} else {
  new BlueskyModerator();
}
# ModMaster Browser Extension

A browser extension that adds moderation controls directly to bsky.app, allowing you to ban users and remove posts without leaving the Bluesky interface.

![Extension Demo](https://img.shields.io/badge/Status-Ready%20to%20Use-brightgreen)
![Chrome](https://img.shields.io/badge/Chrome-Compatible-green)
![Edge](https://img.shields.io/badge/Edge-Compatible-green)
![Firefox](https://img.shields.io/badge/Firefox-Compatible-green)

## 🚀 Quick Install

### Method 1: Download ZIP (Easiest)
1. **[Download Latest Release](../../releases/latest)** or click the green "Code" button → "Download ZIP"
2. Extract the ZIP file
3. Open Chrome/Edge: `chrome://extensions/` or `edge://extensions/`
4. Enable "Developer mode" (toggle in top right)
5. Click "Load unpacked" and select the extracted folder
6. Done! 🎉

### Method 2: Git Clone
```bash
git clone https://github.com/YOUR_USERNAME/modmaster-browser.git
cd modmaster-browser
```
Then follow steps 3-6 above.

## ⚙️ Setup

1. **Get API Key**: 
   - Go to your ModMaster web app
   - Settings → API Keys → Create New Key
   - Copy the key (starts with `fm_live_`)

2. **Configure Extension**:
   - Click the 🛡️ extension icon in your browser toolbar
   - Paste your API key
   - Enter your server URL (usually `https://modmaster.fema.monster`)
   - Click "Test Connection"
   - You should see "Connection successful!" ✅

## 🎯 Features

### On Posts
- **🛡️ Button**: Appears next to like/repost buttons
- **Quick Actions**:
  - Ban User (adds to global ban list)
  - Remove Post (from your configured feeds)
  - Remove from All Feeds

### On Profiles  
- **Moderation Panel**: Appears on any profile page
- **Bulk Actions**:
  - Ban from Global List
  - Ban from All Your Feeds
  - Unban from Global
  - Unban from All Feeds

### Smart Features
- ✅ Real-time notifications
- ✅ Automatic post/user detection
- ✅ Dark mode support
- ✅ Secure API key storage
- ✅ Connection status indicator

## 📱 Browser Support

| Browser | Status | Notes |
|---------|--------|-------|
| Chrome | ✅ Full Support | Recommended |
| Edge | ✅ Full Support | Same as Chrome |
| Firefox | ✅ Compatible | May need minor tweaks |
| Safari | ❌ Not Supported | Different extension system |

## 🔧 Development

### File Structure
```
├── manifest.json     # Extension configuration
├── content.js        # Main script (injects UI)
├── popup.html/js     # Settings popup
├── background.js     # Service worker
├── styles.css        # Extension styles
└── build.sh         # Build script
```

### Local Development
1. Clone this repo
2. Make changes to the files
3. Go to `chrome://extensions/`
4. Click the refresh button on the extension card
5. Test on bsky.app

### Building
```bash
chmod +x build.sh
./build.sh
```

## 🐛 Troubleshooting

### Extension Not Working?
- ✅ Check you have a valid API key
- ✅ Verify server URL is correct
- ✅ Try refreshing bsky.app
- ✅ Check browser console for errors

### Can't See Moderation Buttons?
- ✅ Make sure you're on bsky.app (not other Bluesky clients)
- ✅ Try refreshing the page
- ✅ Check if extension is enabled in browser settings

### API Errors?
- ✅ Test connection in extension popup
- ✅ Make sure your Feed Moderator server is running
- ✅ Check if API key has expired

## 🔒 Security & Privacy

- **Local Storage**: API keys stored securely in browser sync storage
- **HTTPS Only**: All API calls use encrypted connections
- **No Tracking**: Extension doesn't collect or transmit personal data
- **Open Source**: All code is public and auditable

## 📝 Changelog

### v1.0.0 (Latest)
- ✅ Initial release
- ✅ Post-level moderation
- ✅ Profile-level moderation  
- ✅ Settings popup
- ✅ Real-time notifications
- ✅ Chrome/Edge/Firefox support

## 🤝 Contributing

1. Fork this repository
2. Create a feature branch: `git checkout -b feature-name`
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

MIT License - feel free to use, modify, and distribute.

## 🆘 Support

- **Issues**: [Create an issue](../../issues) on GitHub
- **Questions**: Check existing issues or create a new one
- **Updates**: Watch this repo for new releases

---

**Made with ❤️ for the Bluesky community**